package java3;
import java.util.*;
public class ExampleOfArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age[] = new int[5];
		Scanner s = new Scanner(System.in);
		for(int i=0; i <= age.length;i++)
		{
			System.out.println("Enter the student age:");
			age[i] = s.nextInt();
		}

	}

}
