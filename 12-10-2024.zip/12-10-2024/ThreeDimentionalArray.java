package java5;
import java.util.*;
public class ThreeDimentionalArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age[][][] = new int[2][2][5];
		Scanner s = new Scanner(System.in);
		for(int i=0;i<=age.length-1;i++)//college
		{
			for(int j=0;j<=age[i].length-1;j++)//classroom
			{
				for(int k=0;k<=age[i][j].length-1;k++)
				{
					System.out.println("Enter the age of student "+i+"belongs to classroom"+j+"in college"+i);
					age[i][j][k] = s.nextInt();
				}
			}
		}
		System.out.println("age is");
		for(int i=0;i<=age.length-1;i++)//college
		{
			for(int j=0;j<=age[i].length-1;j++)//classroom
			{
				for(int k=0;k<=age[i][j].length-1;k++)
				{
					System.out.println("Enter the age of student "+i+"belongs to classroom"+j+"in college"+i);
					age[i][j][k] = s.nextInt();
				}
			}
		}
	}

}
