package java5;
import java.util.*;
public class JaggaledArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age[][] = new int[2][];
		age[0] = new int[5];
		age[1] = new int[10];
		Scanner s = new Scanner(System.in);
		for(int i=0;i<=age.length-1;i++)//classroom
		{
			for(int j = 0;i<=age[i].length-1;j++)//student
			{
				System.out.println("Enter the age of student belongs to classroom " + i +" student "+j);
				age[i][j] = s.nextInt();
			}
		}
		System.out.println("the ages are");
		for(int i=0;i<=age.length-1;i++)//classroom
		{
			for(int j = 0;i<=age[i].length-1;j++)//student
			{
				System.out.println("Enter the age of student belongs to classroom" +i+"student"+j);
				
			}
		}
		
		
	}

}
